package com.example.fragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.fragment.fragment.FFragment;
import com.example.fragment.fragment.SFragment;
import com.example.fragment.fragment.ThFragment;

public class Adapterfragment extends FragmentPagerAdapter {


    public Adapterfragment(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new FFragment();
            case 1:
                return new SFragment();
            case 2:
                return new ThFragment();
        }
        return getItem(position);
    }

    @Override
    public int getCount() {
        return 3;
    }
}
