package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ViewPager vp = findViewById(R.id.vp);
        TabLayout tabLayout = findViewById(R.id.tl);

        tabLayout.setupWithViewPager(vp);

        Adapterfragment fa = new Adapterfragment(getSupportFragmentManager());
        vp.setAdapter(fa);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_baseline_home_24);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_baseline_elderly_24);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_baseline_fastfood_24);



    }
}
